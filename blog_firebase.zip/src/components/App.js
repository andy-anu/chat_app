import React from "react";
import Posts from "./Posts";
import "bootstrap/dist/css/bootstrap.css";
import { BrowserRouter, Route } from "react-router-dom";
import DetailedPost from "./DetailedPost";
import EditPost from "./EditPost";
import Navbar from "./Navbar";
import CreatePost from "./CreatePost";
const App = () => {
  return (
    <BrowserRouter>
      <Navbar />
      <div className="container">
        <Route exact path="/" component={Posts} />
        <Route path="/detailed/:id" component={DetailedPost} />
        <Route path="/edit/:id" component={EditPost} />
        <Route path="/createpost" component={CreatePost} />
      </div>
    </BrowserRouter>
  );
};

export default App;
